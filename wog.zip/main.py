import requests
import app
from app import diff_chosen

difficulty = diff_chosen

app.welcome()
app.start_play()

